package mk.ukim.finki.dianstechnicalprototype.model.enumerations;

public enum WishListStatus {
    CREATED,
    FINISHED
}

