package mk.ukim.finki.dianstechnicalprototype.model.exceptions;

public class InvalidArgumentsException extends RuntimeException {
}
