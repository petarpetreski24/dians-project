package mk.ukim.finki.dianstechnicalprototype.model.exceptions;

public class PasswordsDoNotMatchException extends RuntimeException {
}
